package com.bitbucket.lonelydeveloper97.wifiproxysettingslibrary.proxy_change_realisation.wifi_network.exceptions;

public class ApiNotSupportedException extends Exception {

    public ApiNotSupportedException() {
        super("Api version not supported");
    }

}

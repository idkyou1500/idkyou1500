package uci.localproxy.tracescreens.tracedetails;

import android.support.v7.app.AppCompatActivity;

/**
 * Created by daniel on 17/02/18.
 */

public class TraceDetailsActivity extends AppCompatActivity {
}

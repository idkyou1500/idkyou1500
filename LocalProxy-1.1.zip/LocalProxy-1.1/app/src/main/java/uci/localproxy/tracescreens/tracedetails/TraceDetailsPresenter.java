package uci.localproxy.tracescreens.tracedetails;

/**
 * Created by daniel on 17/02/18.
 */

public class TraceDetailsPresenter implements TraceDetailsContract.Presenter {



    @Override
    public void addAsFirewallRule(String rule, String appPackageName) {

    }

    @Override
    public void result(int requestCode, int resultCode) {

    }

    @Override
    public void onDestroy() {

    }

    @Override
    public void start() {

    }
}

package uci.localproxy.tracescreens.tracedetails;

/**
 * Created by daniel on 17/02/18.
 */

public class TraceDetailsFragment {
}
